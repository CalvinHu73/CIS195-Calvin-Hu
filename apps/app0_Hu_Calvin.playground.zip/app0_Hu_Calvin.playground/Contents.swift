import UIKit

// App 0
let name = "Calvin Hu"
let pennId = 80922421
print("Hello World! My name is \(name) and my pennId is \(pennId)")


