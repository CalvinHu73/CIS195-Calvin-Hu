
//
//  ViewController.swift
//  app2_Hu_Calvin
//
//  Created by Calvin Hu on 9/16/20.
//  Copyright © 2020 Calvin Hu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var collectionOfButtons: Array<UIButton>?
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var scoreLabel1: UILabel!
    @IBOutlet weak var scoreLabel2: UILabel!
    @IBOutlet weak var turnLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        clearBoard(self)
    }
    
    @IBAction func onClick(_ sender: UIButton) {
        if Bool.random() {
            sender.setImage(UIImage(named: "mark-x"), for: .normal)
        } else {
            sender.setImage(UIImage(named: "mark-o"), for: .normal)
        }
        if turnLabel.text == "Player 1's Turn" {
            turnLabel.text = "Player 2's Turn"
            scoreLabel1.text = "Player 1 Score"
            scoreLabel2.text = "Player 2 Score"
        } else {
            turnLabel.text = "Player 1's Turn"
            scoreLabel1.text = "P1 Score"
            scoreLabel2.text = "P2 Score"
        }
    }
    
    @IBAction func clearBoard(_ sender: Any) {
        for button in collectionOfButtons! {
            button.setImage(UIImage(named: "mark-none"), for: .normal)
        }
    }
}
